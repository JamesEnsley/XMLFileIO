/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package xmlfileio;
import java.io.*;
import java.io.IOException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import java.util.*;
import org.xml.sax.*;


/**
 * Programmer: James Ensley
 * Date: December 8th, 2020
 * Program Name: XMLFileIO
 * Program Description: Creates XML file within java, modifying the file using JDOM, and then using java
 * to print the updated XML file out on to the screen
 */

public class XMLFileIO {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    try {
        //Creates xml file, with the ISO 8859_1 encoding style, that is written to
        OutputStream fout= new FileOutputStream("timetable.xml");
        OutputStream bout= new BufferedOutputStream(fout);
        OutputStreamWriter out = new OutputStreamWriter(bout, "8859_1");
        
        //help define the XML encoding to be used
        out.write("<?xml version=\"1.0\" ");
        out.write("encoding=\"ISO-8859-1\"?>\r\n");
        
        //writes in xml file
        out.write("<Timetable>\r\n");
        out.write("<Course>\r\n");
        out.write("<code>ICS4U</code>\r\n");
        out.write("<description>Computer Programming, Grade 12, University</description>\r\n");
        out.write("<teacher>Teacher A</teacher>\r\n");
        out.write("<room>Lab 8-11</room>\r\n");
        out.write("</Course> \r\n");
        out.write("</Timetable>\r\n");
        out.flush();  //flushes possible remaining data
        out.close();
      }
    
    //handles errors
      catch (UnsupportedEncodingException e) {
        System.out.println(
         "This VM does not support the Latin-1 character set."
        );
      }
      catch (IOException e) {
        System.out.println(e.getMessage());
      }    
    
    //prompt that waits for user to input '1' before modifying the xml file
    System.out.println("xml file has been created"); //notifies user that file has been created
    System.out.println("Enter '1' to modify it"); //prompt
    Scanner sc = new Scanner(System.in);
    int a = sc.nextInt(); //scans input from user
    if (a == 1){ //if '1' is entered, the program continues
       try {
                //creates docBuilder objects that creates a document from the xml file just made
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		Document doc = docBuilder.parse("timetable.xml");
                
                //initializes nodes that elements are added onto
                Node timetable=doc.getElementsByTagName("Timetable").item(0);
                Node course = doc.getElementsByTagName("Course").item(0);
                
                //intializes elements that will be added to the nodes
                Element course1 = doc.createElement("Course");
                Element code1 = doc.createElement("code");
                Element description1 = doc.createElement("description");
                Element teacher1 = doc.createElement("teacher");
                Element room1 = doc.createElement("room");
                Element school1 = doc.createElement("school");
                
                
                //Adds another course node to timetable nodes(another child node)
                timetable.appendChild(course1);
                
                //Adds element 'code' to new course node
                course1.appendChild(code1); //adds code element
                code1.setTextContent("SCH4UI-02"); //sets elements content
                
                //Adds element 'description' to new course node
                course1.appendChild(description1); //adds description element
                description1.setTextContent("Chemistry, Grade 12, University"); //sets elements content
                
                //Adds element 'teacher' to new course node
                course1.appendChild(teacher1); //adds teacher element
                teacher1.setTextContent("Mrs. Rowlandson"); //sets elements content
                
                //Adds element 'room' to new course node
                course1.appendChild(room1); //adds room element
                room1.setTextContent("Room 233"); //sets elements content
                
                //Adds element 'school' to new course node
                course1.appendChild(school1); //adds school element
                school1.setTextContent("KCI"); //sets elements content
                
                //initializes 'school' element added to original course node
		Element school = doc.createElement("school");    
		school.appendChild(doc.createTextNode("KCI")); //sets context of element
		course.appendChild(school); //adds 'school' element to original course node                    

		NodeList list = course.getChildNodes(); //initializes an array of all nodes in xml file
                
                //goes through each node, if there is a teacher node, replace its content with 'Mr.Merrit'
		for (int i = 0; i < list.getLength(); i++) {  
                   Node node = list.item(i); //goes through each node in the node array (NodeList)
		   if ("teacher".equals(node.getNodeName())) { //if the nodes name is 'teacher'
			node.setTextContent("Mr.Merrit"); //sets content to 'Mr.Merrit'
		   }
		}
                
                // Create a Transformer factory, that makes transformer objects that turns to document into a DOM source, which can be turned into an XML file via StreamResult
                TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(new File("timetable.xml"));
		transformer.transform(source, result);

                // error checking
	   } catch (ParserConfigurationException pce) {
		pce.printStackTrace();
	   } catch (TransformerException tfe) {
		tfe.printStackTrace();
	   } catch (IOException ioe) {
		ioe.printStackTrace();
	   } catch (SAXException sae) {
		sae.printStackTrace();
	   } 
       
           System.out.println("The xml file has been modified"); //notifies user that file has been modified
           System.out.println("Enter '1' again to output to console"); //prompt
           int b = sc.nextInt(); //scans for user input
           if (b == 1){ //if user inputs '1', output xml file
               
            try {
            //creates docBuilder objects that creates a document from the xml file just made
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document doc = db.parse(new File("timetable.xml"));
            
            doc.getDocumentElement().normalize(); //normalizes each node so output text isn't distorted
            NodeList timeTable = doc.getElementsByTagName("Course"); //initializes array of course nodes
            int totalCourses = timeTable.getLength(); //gets number of course nodes
            for (int s = 0; s<totalCourses; s++) {
                Node courseNode = timeTable.item(s); //Goes through each course node
                if (courseNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element courseElement = (Element) courseNode;
                    
                    //course output to console
                    System.out.println("Course " + (s+1) + ":");
                    
                    //code output to console
                    NodeList codeList = courseElement.getElementsByTagName("code"); //creates an array of code nodes
                    Element codeElement = (Element) codeList.item(0); //retrieves all elements from the node 'code'
                    NodeList textFNList = codeElement.getChildNodes(); //retrieves all content from the elements in the node 'code'
                    System.out.println("code: " + ((Node)textFNList.item(0)).getNodeValue().trim()); //outputs
                    
                    //description output to console
                    NodeList descriptionList = courseElement.getElementsByTagName("description"); //creates an array of description nodes
                    Element descriptionElement = (Element)descriptionList.item(0); //retrieves all elements from the node 'description'
                    NodeList textLNList = descriptionElement.getChildNodes(); //retrieves all content from the elements in the node 'description'
                    System.out.println("description: " + ((Node)textLNList.item(0)).getNodeValue().trim()); //outputs
                    
                    //teacher output to console
                    NodeList teacherList = courseElement.getElementsByTagName("teacher"); //creates an array of teacher nodes
                    Element teacherElement = (Element)teacherList.item(0); //retrieves all elements from the node 'teacher'
                    NodeList textTeacherList = teacherElement.getChildNodes(); //retrieves all content from the elements in the node 'teacher'
                    System.out.println("teacher: " + ((Node)textTeacherList.item(0)).getNodeValue().trim()); //outputs
                    
                    //room output to console
                    NodeList roomList = courseElement.getElementsByTagName("room"); //creates an array of room nodes
                    Element roomElement = (Element)roomList.item(0); //retrieves all elements from the node 'room'
                    NodeList textRoomList = roomElement.getChildNodes(); //retrieves all content from the elements in the node 'room'
                    System.out.println("room: " + ((Node)textRoomList.item(0)).getNodeValue().trim()); //outputs
                    
                    //school output to console
                    NodeList schoolList = courseElement.getElementsByTagName("school"); //creates an array of school nodes
                    Element schoolElement = (Element)schoolList.item(0); //retrieves all elements from the node 'school'
                    NodeList textschoolList = schoolElement.getChildNodes(); //retrieves all content from the elements in the node 'school'
                    System.out.println("school: " + ((Node)textschoolList.item(0)).getNodeValue().trim() + "\n"); //outputs
                }
            } 
            //error checking
            } catch (ParserConfigurationException pce) {
		pce.printStackTrace();
	   } catch (IOException ioe) {
		ioe.printStackTrace();
	   } catch (SAXException sae) {
		sae.printStackTrace();
	   } 
            System.exit(0); //exits
           }
        }
    }
}
    
   



